var interface_o_n_network =
[
    [ "activateNetwork", "interface_o_n_network.html#acb6ba038b71a7d6a35b09f7a99ee0833", null ],
    [ "flushNetwork", "interface_o_n_network.html#abcbdbdefdd43c3d4206c81e1cca52fe0", null ],
    [ "initWithGenome:", "interface_o_n_network.html#a7588d2dd740652ebd90246f14085a059", null ],
    [ "updateSensors:", "interface_o_n_network.html#af559c139622ac7b03d2f8e2ead142105", null ],
    [ "allLinks", "interface_o_n_network.html#a150eb64e2f1075a593cbad960ac03cab", null ],
    [ "allNodes", "interface_o_n_network.html#a39f3f6171c9a4f3e8e7eca275540d207", null ],
    [ "genome", "interface_o_n_network.html#a6debd7d1f65341b1c57bdd1d114e4f40", null ],
    [ "inputNodes", "interface_o_n_network.html#a71fdf8a567599ed7741b7278931bc737", null ],
    [ "numLinks", "interface_o_n_network.html#ab8729a3e63e00846d4e3a2d0af2b4f62", null ],
    [ "numNodes", "interface_o_n_network.html#a16139f3fabb632ded6ddaf2088c22e56", null ],
    [ "outputNodes", "interface_o_n_network.html#a5d72acaa6244edae45acce122202ef86", null ]
];