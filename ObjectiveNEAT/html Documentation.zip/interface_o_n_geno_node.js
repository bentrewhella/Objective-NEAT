var interface_o_n_geno_node =
[
    [ "nodeID", "interface_o_n_geno_node.html#a25c567688e7a8bea48f5c3f16b789a25", null ],
    [ "nodePosition", "interface_o_n_geno_node.html#aba72d2a330e23bf8c823fdcf8fb0c891", null ],
    [ "nodeType", "interface_o_n_geno_node.html#ad5309cab2ab109c4bd01a5ffbddd92bc", null ]
];