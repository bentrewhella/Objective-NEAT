var interface_o_n_pheno_link =
[
    [ "fromNode", "interface_o_n_pheno_link.html#a3f27dbbfbd5cefa3546c04421df4328c", null ],
    [ "isEnabled", "interface_o_n_pheno_link.html#ad1205fc4c8310d8ebb9870469a726373", null ],
    [ "toNode", "interface_o_n_pheno_link.html#a84e6972fa52f7b0c77d8c4077126d580", null ],
    [ "weight", "interface_o_n_pheno_link.html#ae35dd44f5543f4a84838470f51e1324e", null ]
];