var interface_o_n_geno_link =
[
    [ "initNewlyInnovatedLinkFromNode:toNode:withWeight:", "interface_o_n_geno_link.html#a3818db3873f8bd27a301b09fb2696f50", null ],
    [ "fromNode", "interface_o_n_geno_link.html#a2ef435862e90e315ca6a041ab7e42173", null ],
    [ "isEnabled", "interface_o_n_geno_link.html#ac41169f1783def3fa99e3aeaf6b2b308", null ],
    [ "linkID", "interface_o_n_geno_link.html#a05de66d054b009b89a90a7a4a4fe4342", null ],
    [ "toNode", "interface_o_n_geno_link.html#ac3eb05a4a724af17a0cdfbfd069e2026", null ],
    [ "weight", "interface_o_n_geno_link.html#a2d9fd932d2c752c1c0db9a5c35ccdc3a", null ]
];