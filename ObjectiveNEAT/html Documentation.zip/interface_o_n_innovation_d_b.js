var interface_o_n_innovation_d_b =
[
    [ "getNextGenoNodeID", "interface_o_n_innovation_d_b.html#aecfa454e13d1c31a6c0442ed611d2f85", null ],
    [ "getNextInnovationID", "interface_o_n_innovation_d_b.html#afbd5e52229b11775e11aeb70683e26fe", null ],
    [ "getNodeWithID:", "interface_o_n_innovation_d_b.html#a8265a4dcc728429509d5a37057d04059", null ],
    [ "insertNewLink:fromNode:toNode:", "interface_o_n_innovation_d_b.html#a5e8102552aa0dc989730dab5a6649a51", null ],
    [ "insertNewNode:fromNode:toNode:", "interface_o_n_innovation_d_b.html#a9d37924341b02c1d0c471be35f21731a", null ],
    [ "possibleLinkExistsFromNode:toNode:", "interface_o_n_innovation_d_b.html#a5efdf6a02cfcc0b26e148b83391d0627", null ],
    [ "possibleNodeExistsFromNode:toNode:", "interface_o_n_innovation_d_b.html#a0e7a41eb1a81d31b0a0c252b1c8e6f5c", null ],
    [ "sharedDB", "interface_o_n_innovation_d_b.html#a62d41a62a579ecf0d064b0343aac6bfc", null ],
    [ "linkInnovations", "interface_o_n_innovation_d_b.html#ae4676d5c5a834d2ff78a6103971d9066", null ],
    [ "nodeRecord", "interface_o_n_innovation_d_b.html#a4deae46b6905686223847dd39cb5836a", null ]
];