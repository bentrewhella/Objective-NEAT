var interface_o_n_pheno_node =
[
    [ "activate", "interface_o_n_pheno_node.html#aec38f40ef6e077be24e9a0d77a62ae5f", null ],
    [ "fsigmoid", "interface_o_n_pheno_node.html#a4c14ecb42e1906dbe29f61e9f90d4204", null ],
    [ "activationValue", "interface_o_n_pheno_node.html#a1b19ccc672ede6d6cafda7bc04780e66", null ],
    [ "hasChangedSinceLastTraversal", "interface_o_n_pheno_node.html#a45da69c37bf3bed4fd2be8d7fc00a218", null ],
    [ "incomingPhenoLinks", "interface_o_n_pheno_node.html#a1b3d1914ac7030203a38dd0fd21fef8c", null ],
    [ "lastActivationValue", "interface_o_n_pheno_node.html#a667071c8ce133ce5772fe9f9f856f1ca", null ],
    [ "nodeID", "interface_o_n_pheno_node.html#a3a31804625493098b9d368ddceaaa7c3", null ],
    [ "nodeType", "interface_o_n_pheno_node.html#a2bb5a1aafaee850443f5fd88f83d1a05", null ],
    [ "outgoingPhenoLinks", "interface_o_n_pheno_node.html#a9dca8ae42fd4599da9862e49e3d180f4", null ]
];