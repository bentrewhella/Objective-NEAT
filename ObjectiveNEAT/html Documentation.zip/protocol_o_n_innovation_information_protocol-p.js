var protocol_o_n_innovation_information_protocol-p =
[
    [ "getInnovationID", "protocol_o_n_innovation_information_protocol-p.html#af57c11dda7af0b04df8dc0a88aa55039", null ]
];