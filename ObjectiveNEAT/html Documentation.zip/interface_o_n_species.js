var interface_o_n_species =
[
    [ "addOrganism:", "interface_o_n_species.html#ac91251c4e102f13b71b6521a69da965d", null ],
    [ "clearAndAge", "interface_o_n_species.html#a3c1a41394375bd8c193751cf546c13b2", null ],
    [ "fittestOrganism", "interface_o_n_species.html#a5a70369dce1a4caa0a4b3a36d0ec9799", null ],
    [ "numberToSpawnBasedOnAverageFitness:", "interface_o_n_species.html#ab557c221f6864f6cd9b1a41b13b1e4f2", null ],
    [ "shouldIncludeOrganism:", "interface_o_n_species.html#a8823acd089f8b5bd2f5069ac94ec528b", null ],
    [ "spawnOrganisms:", "interface_o_n_species.html#a39e8fb1b20028a49047124373eb6cfec", null ],
    [ "speciesID", "interface_o_n_species.html#afcc2a352db3465ccb1a971ad961fdc0b", null ],
    [ "age", "interface_o_n_species.html#ac1777f526c61091af9e9feb8f2453273", null ],
    [ "ageSinceImprovement", "interface_o_n_species.html#ab6c62b3bf3de5854f06be3d72ae613ae", null ],
    [ "fittestOrganism", "interface_o_n_species.html#a17d4708913e9e9f2f3c82fc5e263c786", null ],
    [ "speciesFitnessTotal", "interface_o_n_species.html#a8a999006888428a72586373e359c80c7", null ],
    [ "speciesOrganisms", "interface_o_n_species.html#a70e5973b7a874a50240bd28bd4c29d78", null ]
];