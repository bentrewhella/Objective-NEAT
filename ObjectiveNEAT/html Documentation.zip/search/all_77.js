var searchData=
[
  ['weight',['weight',['../interface_o_n_geno_link.html#a2d9fd932d2c752c1c0db9a5c35ccdc3a',1,'ONGenoLink::weight()'],['../interface_o_n_pheno_link.html#ae35dd44f5543f4a84838470f51e1324e',1,'ONPhenoLink::weight()']]]
];
