var searchData=
[
  ['lastactivationvalue',['lastActivationValue',['../interface_o_n_pheno_node.html#a667071c8ce133ce5772fe9f9f856f1ca',1,'ONPhenoNode']]],
  ['linkid',['linkID',['../interface_o_n_geno_link.html#a05de66d054b009b89a90a7a4a4fe4342',1,'ONGenoLink']]]
];
