var searchData=
[
  ['getinnovationid',['getInnovationID',['../protocol_o_n_innovation_information_protocol-p.html#af57c11dda7af0b04df8dc0a88aa55039',1,'ONInnovationInformationProtocol-p']]],
  ['getnextgenonodeid',['getNextGenoNodeID',['../interface_o_n_innovation_d_b.html#aecfa454e13d1c31a6c0442ed611d2f85',1,'ONInnovationDB']]],
  ['getnextinnovationid',['getNextInnovationID',['../interface_o_n_innovation_d_b.html#afbd5e52229b11775e11aeb70683e26fe',1,'ONInnovationDB']]],
  ['getnodewithid_3a',['getNodeWithID:',['../interface_o_n_innovation_d_b.html#a8265a4dcc728429509d5a37057d04059',1,'ONInnovationDB']]]
];
