var searchData=
[
  ['destroynetwork',['destroyNetwork',['../interface_o_n_organism.html#af047376f47ca536b04068d70258a044d',1,'ONOrganism']]],
  ['developnetwork',['developNetwork',['../interface_o_n_organism.html#a33fb74a35b272064636424bdcf160a87',1,'ONOrganism']]]
];
