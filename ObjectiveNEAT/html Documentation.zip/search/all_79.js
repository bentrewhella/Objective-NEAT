var searchData=
[
  ['youngspeciesagethreshold',['youngSpeciesAgeThreshold',['../interface_o_n_parameter_controller.html#acceddc9f4ec5fccd350bdf2ac8dbf843',1,'ONParameterController']]],
  ['youngspeciesfitnessbonus',['youngSpeciesFitnessBonus',['../interface_o_n_parameter_controller.html#a8b2a7f1d50028ec1baf76e50dbaa8fa6',1,'ONParameterController']]]
];
