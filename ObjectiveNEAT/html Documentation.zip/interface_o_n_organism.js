var interface_o_n_organism =
[
    [ "compareFitnessWith:", "interface_o_n_organism.html#a11c2918b95f728369b514f62dec73fa8", null ],
    [ "destroyNetwork", "interface_o_n_organism.html#af047376f47ca536b04068d70258a044d", null ],
    [ "developNetwork", "interface_o_n_organism.html#a33fb74a35b272064636424bdcf160a87", null ],
    [ "initWithGenome:", "interface_o_n_organism.html#af60a8e847e13ee845ad4188f04afd67d", null ],
    [ "reproduceChildOrganism", "interface_o_n_organism.html#a8f7aa1b9aa363ecdcfd6b4ad2a71ce59", null ],
    [ "reproduceChildOrganismWithOrganism:", "interface_o_n_organism.html#abb9927d32d8c026de9e2cc48c2211485", null ],
    [ "fitness", "interface_o_n_organism.html#a41369a0608dd6ff1841a99376214ebf6", null ],
    [ "genome", "interface_o_n_organism.html#a599b2edf6818ba5f8d2378ef1487e948", null ],
    [ "network", "interface_o_n_organism.html#af84826afa8a53173fd05b729c0520b6a", null ]
];