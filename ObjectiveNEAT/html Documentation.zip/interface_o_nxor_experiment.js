var interface_o_nxor_experiment =
[
    [ "solutionOrganism", "interface_o_nxor_experiment.html#a99a727a7cdfc5304ba170530ec169224", null ]
];