var interface_o_n_innovation =
[
    [ "nodeOrLink", "interface_o_n_innovation.html#a904e275fe4b82aa2de1041dc17364507", null ],
    [ "fromNodeID", "interface_o_n_innovation.html#a81f05c2a0a3d608ebfc225d70950cf29", null ],
    [ "nodeOrLink", "interface_o_n_innovation.html#aeecbb24c92ac5c68e89b5607d37633f6", null ],
    [ "toNodeID", "interface_o_n_innovation.html#a21c474ff399866edafee5679262ab1f1", null ]
];